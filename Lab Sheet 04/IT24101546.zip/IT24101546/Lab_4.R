#X1 = Team Attendance (Average number of spectators for a match that the team play)
#X2 = Team Salary (Earning of the team)
#X3 = Years (Years since the team has owned a stadium)

##Part01
##Setting Directory
setwd("C:\\Users\\IT24101546\\Documents\\Lab 04-20250821\\IT24101546")

##importing the data set
data<-read.table("DATA 4.txt", header = TRUE, sep = " ")

##View the file in a separate window
fix(data)

##Attach the file into R. So, you can call the variables by their names
attach(data)


##Part02
#Part(a)
#Obtaining Box plots
boxplot(X1, main = "Box plot for team attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for team salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

#Obtaining Histogram
hist(X1, ylab = "Frequancy", xlab = "Team attendace", main = "Histrogram for team attendace")
hist(X2, ylab = "Frequancy", xlab = "Team salary", main = "Histrogram for team salary")
hist(X3, ylab = "Frequancy", xlab = "years", main = "Histrogram for years")

#Part(b)
#mean
mean(X1)
mean(X2)
mean(X3)

#median
median(X1)
median(X2)
median(X3)

#Standard Deviation
sd(X1)
sd(X2)
sd(X3)

##Part(c)
#Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

#For X1
#Getting only five number summary
quantile(X1)

#Calling first Quartile using index value
quantile(X1)[2]

#Calling third Quartile using index value
quantile(X1)[4]


##Part(d)
#Obtaining Inter Quatile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)


##Part03
#Function to get the mode of a data set
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts == max(counts)])
}

counts<-table(X3)
#Obtaining the mode of a variable using the function defined above
get.mode(X3)

##Explanation on how each command inside the function works
#Following command is to get the frequency table for the variable 
table(X3)

#Following command will give the maximum frequency in the frequency table
max(counts)

#following command will check wither frequencies in the frequency table equals to the maximum frequency obtained
counts == max(counts)

#This extracts both value and the frequency which gives 'TRUE' in earlier logical function
counts[counts == max(counts)]

#This extracts the value which gives maximum frequency (mode) in earlier logical function 
names(counts[counts == max(counts)])

##Part04
#Function to check the existence of outliers of a data set
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Uper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z<lb | z>ub]), collapse = ", ")))
}

#Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)


##Explanation on how each command inside the function works 
#Following command is to calculate the interval for outliers
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  #Following command is to display the upper boundary and lower boundary of the interval
  print(paste("Uper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  #checking the existance of outliers and display the outliers if exists
  print(paste("Outliers: ", paste(sort(z[z<lb | z>ub]), collapse = ", ")))
  }
